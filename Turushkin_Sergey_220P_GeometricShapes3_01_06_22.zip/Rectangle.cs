﻿//Turushkin Sergey, 220P "GeometricShapes3" 01.06.22

using System;

namespace GeometricShapes3
{
    [Serializable]
    class Rectangle : FilledFigure
    {
        public decimal Height;
        public decimal Width;

        public Rectangle(Point point, decimal height, decimal width) : base(point)
        {
            Height = height;
            Width = width;
        }

        public override string Draw()
        {
            return ($"Rectangle: at {basePoint}, Height: {Height}, Width: {Width}");
        }
    }
}