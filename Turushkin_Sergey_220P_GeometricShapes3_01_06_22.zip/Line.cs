﻿//Turushkin Sergey, 220P "GeometricShapes3" 01.06.22

using System;

namespace GeometricShapes3
{
    [Serializable]
    class Line : Figure
    {
        public Point A
        {
            get { return basePoint; }
            set { basePoint = value; }
        }
        public Point B;

        public StrokeData Stroke;

        public Line(Point a, Point b) : base(a)
        {
            B = b;
        }

        public Line(decimal x1, decimal y1, decimal x2, decimal y2) : base(x1, y1)
        {
            B = new Point(x2, y2);
        }

        public override string Draw()
        {
            return ($"Line: A {A} - B {B}, Stroke width: {Stroke.Width}, Stroke color: {Stroke.Color}");
        }
    }
}