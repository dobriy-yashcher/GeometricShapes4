﻿//Turushkin Sergey, 220P "GeometricShapes3" 01.06.22

using System;
using System.Collections.Generic;

namespace GeometricShapes3
{
    [Serializable]
    public struct Point
    {
        public decimal X;
        public decimal Y;

        public Point(decimal x, decimal y)
        {
            X = x;
            Y = y;
        }

        public override string ToString()
        {
            return $"[{X}, {Y}]";
        }
    }

    [Serializable]
    public class Figure
    {
        protected Point basePoint;

        public Figure(Point point)
        {
            basePoint = point;
        }

        public Figure(decimal x = 0, decimal y = 0)
        {
            basePoint = new Point(x, y);
        }

        public virtual string Draw()
        { return ""; }

    }
}