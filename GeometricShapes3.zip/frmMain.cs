﻿//Turushkin Sergey, 220P "GeometricShapes3" 01.06.22

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GeometricShapes3
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void pnlWorkPlace_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            image.Add(new Line(1, 2, 3, 4));
            image.Add(new Triangle(1, 2, 3, 4, 5, 6));
            image.Add(new Circle(new Point(1, 2), 4));
            image.Add(new Rectangle(new Point(1, 2), 4, 5));
        }

        private void lstVFigures_SelectedIndexChanged(object sender, EventArgs e)
        {
            //MessageBox.Show(lstVFigures.Activation.GetType().ToString());
            int? selectedCountry = null;

            try
            {
                selectedCountry = lstVFigures.FocusedItem.Index;
            }
            catch (Exception) { }

            switch (selectedCountry)
            {
                case 0:
                    HidePanel();
                    pnlLineData.Visible = true;
                    break;
                case 1:
                    HidePanel();
                    pnlCircleData.Visible = true;
                    break;
                case 2:
                    HidePanel();
                    pnlRectangleData.Visible = true;
                    break;
                case 3:
                    HidePanel();
                    pnlTriangleData.Visible = true;
                    break;
                default:
                    //MessageBox.Show(selectedCountry.ToString()); 
                    break;
            }
        }

        private void HidePanel()
        {
            pnlLineData.Visible = false;
            pnlCircleData.Visible = false;
            pnlRectangleData.Visible = false;
            pnlTriangleData.Visible = false;
        }

        private void btnLineAdd_Click(object sender, EventArgs e)
        {
            var line = new Line(nmcLinePointAx.Value, nmcLinePointAy.Value, nmcLinePointBx.Value, nmcLinePointBy.Value);
            line.Stroke.Width = nmcLineStrokeWidth.Value;
            line.Stroke.Color = maskLineStrokeColor.Text;

            image.Add(line);
            txtlWorkPlace.Text += line.Draw() + Environment.NewLine;
        }

        private void btnTriangleAdd_Click(object sender, EventArgs e)
        {
            var p1 = new Point(nmcTrianglePointAx.Value, nmcTrianglePointAy.Value);
            var p2 = new Point(nmcTrianglePointBx.Value, nmcTrianglePointBy.Value);
            var p3 = new Point(nmcTrianglePointCx.Value, nmcTrianglePointCy.Value);
            var triangle = new Triangle(p1, p2, p3);

            image.Add(triangle);
            txtlWorkPlace.Text += triangle.Draw() + Environment.NewLine;
        }

        private void btnCircleAdd_Click(object sender, EventArgs e)
        {
            var p1 = new Point(nmcCirclePointAx.Value, nmcCirclePointAy.Value);
            var circle = new Circle(p1, nmcCircleRadius.Value);

            image.Add(circle);
            txtlWorkPlace.Text += circle.Draw() + Environment.NewLine;
        }

        private void btnRectangleAdd_Click(object sender, EventArgs e)
        {
            var p1 = new Point(nmcRectanglePointAx.Value, nmcRectanglePointAy.Value);
            var rectandle = new Rectangle(p1, nmcRectangleHeight.Value, nmcRectangleWidth.Value);

            image.Add(rectandle);
            txtlWorkPlace.Text += rectandle.Draw() + Environment.NewLine;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (saveFileDialog.ShowDialog() == DialogResult.Cancel)
                return;

            string filename = saveFileDialog.FileName;

            System.IO.File.WriteAllText(filename, txtlWorkPlace.Text);
            MessageBox.Show("Файл сохранен");
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            if (openFileDialog.ShowDialog() == DialogResult.Cancel)
                return;

            string filename = openFileDialog.FileName;

            string fileText = System.IO.File.ReadAllText(filename);
            txtlWorkPlace.Text = fileText;
            MessageBox.Show("Файл открыт");
        }
    }
}
