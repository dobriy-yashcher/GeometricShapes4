﻿//Turushkin Sergey, 220P "GeometricShapes3" 01.06.22

using System;

namespace GeometricShapes3
{
    [Serializable]
    class Circle : FilledFigure
    {
        public decimal Radius;
        public Circle(Point point, decimal radius) : base(point)
        {
            Radius = radius;
        }

        public override string Draw()
        {
            return ($"Circle: at {basePoint}, Radius: {Radius}");
        }
    }
}