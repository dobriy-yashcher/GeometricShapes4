﻿//Turushkin Sergey, 220P "GeometricShapes3" 01.06.22

using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace GeometricShapes3
{
    [Serializable]
    public class Figires
    {
        public  List<Figure> page = new List<Figure>(); 

        public Figires() { }

        public void Add(Figure figure)
        {
            page.Add(figure);
        }

        public void Save(string path)
        {
            DirectoryInfo dirInfo = new DirectoryInfo(path);
            if (!dirInfo.Exists)
            {
                dirInfo.Create();
            }

            var formatter = new BinaryFormatter();
            using (FileStream fs = new FileStream($"{path}/note.txt", FileMode.OpenOrCreate))
            {
                formatter.Serialize(fs, page);
            }

            /*using (StreamWriter sw = new StreamWriter(path, false, System.Text.Encoding.Default))
            {
                foreach (var fig in page)
                {
                    sw.WriteLine(fig);
                }
            }*/
        }

        public void Load(string path)
        {
            var formatter = new BinaryFormatter();

            using (FileStream fs = new FileStream(path, FileMode.OpenOrCreate))
            {
                page = (List<Figure>)formatter.Deserialize(fs);
            }

            /*using (StreamReader sr = new StreamReader(path, System.Text.Encoding.Default))
            {
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    Console.WriteLine(line);
                }
            }*/
        }

        public string Draw()
        {
            string result = "";

            foreach (Figure fig in page)
            {
                result += fig.Draw() + Environment.NewLine;
            }

            return result;
        }
    }
}