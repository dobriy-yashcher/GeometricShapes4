﻿//Turushkin Sergey, 220P "GeometricShapes3" 01.06.22

using System;

namespace GeometricShapes3
{
    [Serializable]
    struct StrokeData
    {
        public decimal Width;
        public string Color;
    }

    [Serializable]
    struct FillData
    {
        public string Color;
    }

    [Serializable]
    class FilledFigure : Figure
    {
        public FillData Fill;
        public StrokeData Stroke;

        public FilledFigure(Point point) : base(point)
        {
            Fill.Color = "0xFFFFFF";
            Stroke.Color = "0x000000";
        }

        public FilledFigure(int x, int y) : base(x, y)
        {
            Fill.Color = "0xFFFFFF";
            Stroke.Color = "0x000000";
        }
    }
}